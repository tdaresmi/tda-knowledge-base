# TDA Knowledge Base

Açık kaynak bilgi sitesi. Next.js 14, Tailwind CSS ve Markdown ile geliştirilmiştir.

## Özellikler

- ✅ 7 kategori (Tarih, Bilim, Günlük Hayat, Teknoloji, Hukuk, Sağlık, Güncel)
- ✅ Markdown dosyalarından otomatik sayfa oluşturma
- ✅ Arama çubuğu (içerikte arama)
- ✅ Her sayfada "Kaynak" bölümü
- ✅ Mobil uyumlu, sade beyaz tema
- ✅ Admin paneli (makale ekleme/silme arayüzü)
- ✅ Static export (Vercel'e kolay deploy)

## Kurulum

```bash
npm install
npm run dev
```

## Vercel'e Deploy

```bash
npm run build
```

`out/` klasörünü Vercel'e yükleyin.

## Yeni Makale Ekleme

1. `/content/[kategori]/` klasörüne `.md` dosyası ekleyin
2. Frontmatter formatı:

```yaml
---
title: "Makale Başlığı"
description: "Kısa açıklama"
date: "2024-01-15"
source: "https://kaynak-site.com"
---
```

3. `npm run build` ile yeniden derleyin

## Klasör Yapısı

```
content/
├── tarih/
├── bilim/
├── gunluk-hayat/
├── teknoloji/
├── hukuk/
├── saglik/
└── guncel/
```

## Lisans

MIT
