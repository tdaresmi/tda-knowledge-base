import Link from 'next/link'
import { ArrowRight, Calendar } from 'lucide-react'

export default function ArticleCard({ article }) {
  return (
    <Link 
      href={`/makale/${article.category}/${article.slug}/`}
      className="group block bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-md hover:border-accent/20 transition-all duration-300"
    >
      <h3 className="font-semibold text-primary text-base group-hover:text-accent transition-colors">
        {article.title}
      </h3>
      <p className="text-sm text-gray-500 mt-2 line-clamp-2">
        {article.description}
      </p>
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-1.5 text-xs text-gray-400">
          <Calendar className="w-3.5 h-3.5" />
          <span>{article.date || 'Tarih belirtilmemiş'}</span>
        </div>
        <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-accent group-hover:translate-x-1 transition-all" />
      </div>
    </Link>
  )
}
