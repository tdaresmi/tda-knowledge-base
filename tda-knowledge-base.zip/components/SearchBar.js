'use client'

import { useState } from 'react'
import { Search, X } from 'lucide-react'
import Link from 'next/link'

export default function SearchBar({ articles }) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [showResults, setShowResults] = useState(false)

  const handleSearch = (e) => {
    const val = e.target.value
    setQuery(val)

    if (val.length < 2) {
      setResults([])
      setShowResults(false)
      return
    }

    const lower = val.toLowerCase()
    const filtered = articles.filter(a => 
      a.title.toLowerCase().includes(lower) ||
      a.description.toLowerCase().includes(lower) ||
      a.categoryName?.toLowerCase().includes(lower)
    )

    setResults(filtered.slice(0, 8))
    setShowResults(true)
  }

  return (
    <div className="relative max-w-2xl mx-auto">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={query}
          onChange={handleSearch}
          placeholder="Makale ara..."
          className="w-full pl-12 pr-10 py-3 rounded-xl border border-gray-200 bg-white focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all shadow-sm"
        />
        {query && (
          <button 
            onClick={() => { setQuery(''); setResults([]); setShowResults(false); }}
            className="absolute right-4 top-1/2 -translate-y-1/2"
          >
            <X className="w-5 h-5 text-gray-400 hover:text-gray-600" />
          </button>
        )}
      </div>

      {showResults && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl border border-gray-200 shadow-lg overflow-hidden z-40">
          {results.map((article, idx) => (
            <Link
              key={idx}
              href={`/makale/${article.category}/${article.slug}/`}
              onClick={() => { setShowResults(false); setQuery(''); }}
              className="block px-4 py-3 hover:bg-gray-50 border-b border-gray-100 last:border-0 transition-colors"
            >
              <div className="font-medium text-primary text-sm">{article.title}</div>
              <div className="text-xs text-gray-500 mt-0.5">{article.categoryName || article.category} · {article.description.slice(0, 80)}...</div>
            </Link>
          ))}
        </div>
      )}

      {showResults && query.length >= 2 && results.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl border border-gray-200 shadow-lg px-4 py-3 text-sm text-gray-500 z-40">
          Sonuç bulunamadı.
        </div>
      )}
    </div>
  )
}
