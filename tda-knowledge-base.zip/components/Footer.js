export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <p className="text-sm text-gray-500 leading-relaxed">
            Bu site eğitim amaçlıdır. Tüm içerikler özetlenerek yazılmıştır. Telifli içerik varsa bildirin kaldırılsın.
          </p>
          <p className="text-xs text-gray-400 mt-4">
            © {new Date().getFullYear()} TDA Knowledge Base
          </p>
        </div>
      </div>
    </footer>
  )
}
