import Link from 'next/link'
import { Clock, FlaskConical, Home, Cpu, Scale, Heart, Newspaper } from 'lucide-react'

const iconMap = {
  Clock, FlaskConical, Home, Cpu, Scale, Heart, Newspaper
}

export default function CategoryCard({ category }) {
  const Icon = iconMap[category.icon] || Newspaper

  return (
    <Link 
      href={`/kategori/${category.slug}/`}
      className="group block bg-white rounded-2xl border border-gray-200 p-6 hover:shadow-lg hover:border-accent/30 transition-all duration-300"
    >
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
          <Icon className="w-6 h-6 text-accent" />
        </div>
        <div>
          <h3 className="font-semibold text-primary text-lg">{category.name}</h3>
          <p className="text-sm text-gray-500">Makaleleri görüntüle</p>
        </div>
      </div>
    </Link>
  )
}
