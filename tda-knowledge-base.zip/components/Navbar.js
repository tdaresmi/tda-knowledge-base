'use client'

import Link from 'next/link'
import { BookOpen, Menu, X } from 'lucide-react'
import { useState } from 'react'

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link href="/" className="flex items-center gap-2">
            <BookOpen className="w-7 h-7 text-accent" />
            <span className="text-xl font-bold text-primary">TDA Knowledge Base</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-secondary hover:text-accent transition-colors text-sm font-medium">
              Ana Sayfa
            </Link>
            <Link href="/admin/" className="text-secondary hover:text-accent transition-colors text-sm font-medium">
              Admin
            </Link>
          </div>

          <button 
            className="md:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white">
          <div className="px-4 py-3 space-y-2">
            <Link href="/" className="block py-2 text-secondary hover:text-accent" onClick={() => setMobileOpen(false)}>
              Ana Sayfa
            </Link>
            <Link href="/admin/" className="block py-2 text-secondary hover:text-accent" onClick={() => setMobileOpen(false)}>
              Admin
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}
