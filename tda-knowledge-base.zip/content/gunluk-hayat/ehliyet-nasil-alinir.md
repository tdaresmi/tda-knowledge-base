---
title: "Ehliyet Nasıl Alınır?"
description: "Türkiye'de ehliyet alma süreci, gerekli belgeler, sınavlar ve maliyet hakkında kapsamlı rehber."
date: "2024-01-15"
source: "https://www.kgm.gov.tr"
---

# Ehliyet Nasıl Alınır?

Türkiye'de ehliyet (sürücü belgesi) almak isteyenlerin izlemesi gereken adımları bu rehberde bulabilirsiniz.

## Gerekli Şartlar

Ehliyet almak için öncelikle bazı temel şartları sağlamanız gerekir:

- **Yaş Şartı:** B sınıfı ehliyet için en az 18 yaşında olmanız gerekir.
- **Eğitim Durumu:** En az ilkokul mezunu olmanız şarttır.
- **Sağlık Raporu:** Sürücü olmaya engel bir sağlık sorununuzun olmaması gerekir.
- **Adli Sicil:** Belirli suçlardan hüküm giymemiş olmanız gerekir.

## Gerekli Belgeler

Başvuru yapmadan önce şu belgeleri hazırlamalısınız:

1. Nüfus cüzdanı fotokopisi
2. 6 adet biyometrik fotoğraf
3. Sağlık raporu (aile hekiminden veya hastaneden)
4. Öğrenim belgesi
5. Adli sicil kaydı
6. Dilekçe

## Süreç Adımları

### 1. Sürücü Kursuna Kayıt

Öncelikle yetkili bir sürücü kursuna kaydolmanız gerekir. Kurslar genellikle teorik ve direksiyon eğitimi paketleri sunar.

### 2. Teorik Eğitim ve Sınav

Kursa kaydolduktan sonra teorik eğitim alırsınız. Eğitim sonunda **e-Sınav** (elektronik sınav) uygulanır. Bu sınavda:

- 50 soru sorulur
- Süre 45 dakikadır
- En az 35 doğru cevap vermeniz gerekir (70 puan)

### 3. Direksiyon Eğitimi

Teorik sınavı geçtikten sonra direksiyon eğitimine başlarsınız. B sınıfı için en az **14 saat** direksiyon eğitimi almanız zorunludur.

### 4. Direksiyon Sınavı

Eğitimleri tamamladıktan sonra direksiyon sınavına girersiniz. Sınavda:

- Araç kontrolü ve güvenlik önlemleri
- Yola kalkış ve duruş
- Şerit değiştirme
- Dönüşler ve kavşaklar
- Park manevraları değerlendirilir

### 5. Ehliyetin Alınması

Her iki sınavı da başarıyla tamamladıktan sonra ehliyetinizi almaya hak kazanırsınız. Ehliyetiniz:

- İl/ilçe nüfus müdürlüklerinden,
- Veya e-Devlet üzerinden başvuru yaparak alınabilir.

## Maliyet

Ehliyet maliyetleri yıllık olarak güncellenir. Genel olarak şu masrafları göz önünde bulundurun:

| Kalem | Yaklaşık Maliyet |
|-------|-----------------|
| Kurs ücreti | 15.000 - 25.000 TL |
| Sınav harcı | 500 - 1.000 TL |
| Sağlık raporu | 200 - 500 TL |
| Ehliyet kart ücreti | 500 - 1.000 TL |

> **Not:** Fiyatlar 2024 yılına ait yaklaşık değerlerdir. Güncel fiyatlar için sürücü kurslarına danışmanız önerilir.

## Sonuç

Ehliyet alma süreci disiplin ve sabır gerektirir. Teorik bilgilerinizi pekiştirmek için Milli Eğitim Bakanlığı'nın yayınladığı kaynakları kullanabilirsiniz. Başarılar!
