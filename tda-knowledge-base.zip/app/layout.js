import './globals.css'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'

export const metadata = {
  title: 'TDA Knowledge Base',
  description: 'Açık kaynak bilgi sitesi - Tarih, Bilim, Günlük Hayat, Teknoloji, Hukuk, Sağlık, Güncel',
}

export default function RootLayout({ children }) {
  return (
    <html lang="tr">
      <body className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  )
}
