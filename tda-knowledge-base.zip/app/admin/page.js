'use client'

import { useState, useEffect } from 'react'
import { categories, getAllArticles } from '@/lib/markdown'
import Link from 'next/link'
import { Trash2, Plus, FileText, ExternalLink, Copy, Check } from 'lucide-react'

// Build-time makaleleri al (server'dan geliyor ama client'ta da kullanabiliriz)
// Bu dosya client component olduğu için getAllArticles() çağrılamaz.
// Bu yüzden mevcut makaleleri props olarak geçmek yerine, 
// admin sayfası sadece localStorage yönetimi yapacak.

// Mevcut makale listesi - build-time bilinen dosyalar
const staticCategories = [
  { slug: 'tarih', name: 'Tarih' },
  { slug: 'bilim', name: 'Bilim' },
  { slug: 'gunluk-hayat', name: 'Günlük Hayat' },
  { slug: 'teknoloji', name: 'Teknoloji' },
  { slug: 'hukuk', name: 'Hukuk' },
  { slug: 'saglik', name: 'Sağlık' },
  { slug: 'guncel', name: 'Güncel' },
]

export default function AdminPage() {
  const [customArticles, setCustomArticles] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [copied, setCopied] = useState(false)

  const [formData, setFormData] = useState({
    category: 'tarih',
    slug: '',
    title: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
    source: '',
    content: '',
  })

  useEffect(() => {
    const saved = localStorage.getItem('tda_custom_articles')
    if (saved) {
      try {
        setCustomArticles(JSON.parse(saved))
      } catch (e) {
        console.error('Parse error', e)
      }
    }
  }, [])

  const saveToStorage = (articles) => {
    localStorage.setItem('tda_custom_articles', JSON.stringify(articles))
    setCustomArticles(articles)
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const newArticle = {
      id: Date.now(),
      ...formData,
      slug: formData.slug.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
    }

    const updated = [...customArticles, newArticle]
    saveToStorage(updated)

    setFormData({
      category: 'tarih',
      slug: '',
      title: '',
      description: '',
      date: new Date().toISOString().split('T')[0],
      source: '',
      content: '',
    })
    setShowForm(false)
  }

  const handleDelete = (id) => {
    if (confirm('Bu makaleyi silmek istediğinize emin misiniz?')) {
      const updated = customArticles.filter(a => a.id !== id)
      saveToStorage(updated)
    }
  }

  const generateMarkdown = (article) => {
    return `---
title: "${article.title}"
description: "${article.description}"
date: "${article.date}"
source: "${article.source}"
---

${article.content}`
  }

  const copyMarkdown = (article) => {
    const md = generateMarkdown(article)
    navigator.clipboard.writeText(md)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-primary">Admin Paneli</h1>
          <p className="text-gray-500 mt-1">Makale ekle, sil ve markdown dosyası oluştur.</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 bg-accent text-white px-4 py-2.5 rounded-xl hover:bg-accent/90 transition-colors font-medium text-sm"
        >
          {showForm ? 'İptal' : <><Plus className="w-4 h-4" /> Yeni Makale</>}
        </button>
      </div>

      {/* Bilgi kutusu */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
        <p className="text-sm text-blue-800">
          <strong>Not:</strong> Burada eklenen makaleler sadece bu tarayıcıda (localStorage) saklanır. 
          Kalıcı olarak eklemek için oluşturulan markdown dosyasını <code className="bg-blue-100 px-1.5 py-0.5 rounded text-xs">/content/[kategori]/[dosya-adi].md</code> olarak kaydedip projeyi yeniden derleyin.
        </p>
      </div>

      {/* Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded-2xl p-6 mb-8 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Kategori</label>
              <select
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent"
              >
                {staticCategories.map(c => (
                  <option key={c.slug} value={c.slug}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">URL Slug</label>
              <input
                type="text"
                value={formData.slug}
                onChange={e => setFormData({...formData, slug: e.target.value})}
                placeholder="ornek-makale-basligi"
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">Başlık</label>
            <input
              type="text"
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
              placeholder="Makale başlığı"
              className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">Kısa Açıklama</label>
            <input
              type="text"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="Makalenin kısa özeti"
              className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Tarih</label>
              <input
                type="date"
                value={formData.date}
                onChange={e => setFormData({...formData, date: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-primary mb-1.5">Kaynak</label>
              <input
                type="text"
                value={formData.source}
                onChange={e => setFormData({...formData, source: e.target.value})}
                placeholder="https://..."
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-primary mb-1.5">İçerik (Markdown)</label>
            <textarea
              value={formData.content}
              onChange={e => setFormData({...formData, content: e.target.value})}
              placeholder="# Başlık\n\nİçerik buraya..."
              rows={10}
              className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent font-mono text-sm"
              required
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-accent text-white px-6 py-2.5 rounded-xl hover:bg-accent/90 transition-colors font-medium text-sm"
            >
              Makale Ekle
            </button>
          </div>
        </form>
      )}

      {/* Örnek Markdown Şablonu */}
      <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6 mb-8">
        <h2 className="text-lg font-semibold text-primary mb-3">Örnek Markdown Şablonu</h2>
        <p className="text-sm text-gray-500 mb-3">
          Dosyayı <code className="bg-white px-1.5 py-0.5 rounded border text-xs">/content/kategori-adi/dosya-adi.md</code> olarak kaydedin:
        </p>
        <pre className="bg-gray-900 text-gray-100 p-4 rounded-xl overflow-x-auto text-sm">
{`---
title: "Makale Başlığı"
description: "Kısa açıklama"
date: "2024-01-15"
source: "https://ornek-kaynak.com"
---

# Giriş

Makale içeriği buraya yazılır.

## Alt Başlık

- Madde 1
- Madde 2

**Kalın metin** ve *italik metin* kullanabilirsiniz.`}
        </pre>
      </div>

      {/* Eklenen Makaleler */}
      <div>
        <h2 className="text-lg font-semibold text-primary mb-4">Eklenen Makaleler ({customArticles.length})</h2>

        {customArticles.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-2xl border border-gray-200">
            <FileText className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">Henüz makale eklenmemiş.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {customArticles.map((article) => (
              <div key={article.id} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <h3 className="font-medium text-primary truncate">{article.title}</h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {staticCategories.find(c => c.slug === article.category)?.name} · {article.slug} · {article.date}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => copyMarkdown(article)}
                    className="p-2 text-gray-400 hover:text-accent hover:bg-accent/10 rounded-lg transition-colors"
                    title="Markdown kopyala"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleDelete(article.id)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Klasör yapısı */}
      <div className="mt-12 bg-gray-50 border border-gray-200 rounded-2xl p-6">
        <h2 className="text-lg font-semibold text-primary mb-3">Klasör Yapısı</h2>
        <pre className="text-sm text-gray-600 font-mono">
{`content/
├── tarih/
│   └── osmanli-imparatorlugu.md
├── bilim/
├── gunluk-hayat/
│   └── ehliyet-nasil-alinir.md
├── teknoloji/
├── hukuk/
├── saglik/
└── guncel/`}
        </pre>
      </div>
    </div>
  )
}
