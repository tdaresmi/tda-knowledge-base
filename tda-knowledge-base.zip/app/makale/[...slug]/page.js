import { notFound } from 'next/navigation'
import { categories, getAllArticleSlugs, getArticleBySlug } from '@/lib/markdown'
import Link from 'next/link'
import { ArrowLeft, Calendar, ExternalLink } from 'lucide-react'

export function generateStaticParams() {
  return getAllArticleSlugs()
}

export function generateMetadata({ params }) {
  const [category, slug] = params.slug
  const article = getArticleBySlug(category, slug)
  return {
    title: article ? `${article.title} - TDA Knowledge Base` : 'Makale',
  }
}

export default function ArticlePage({ params }) {
  const [category, slug] = params.slug
  const article = getArticleBySlug(category, slug)

  if (!article) {
    notFound()
  }

  const categoryName = categories.find(c => c.slug === category)?.name || category

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link 
        href={`/kategori/${category}/`}
        className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-accent transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        {categoryName}
      </Link>

      <article>
        <header className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-4">
            {article.title}
          </h1>
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <span className="inline-flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              {article.date || 'Tarih belirtilmemiş'}
            </span>
            <span className="text-gray-300">|</span>
            <span>{categoryName}</span>
          </div>
        </header>

        <div 
          className="prose-custom"
          dangerouslySetInnerHTML={{ __html: article.contentHtml }}
        />

        {/* Kaynak bölümü */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <h3 className="text-lg font-semibold text-primary mb-3">Kaynak</h3>
          {article.source ? (
            <div className="flex items-start gap-2 text-sm text-gray-600 bg-gray-50 rounded-xl p-4">
              <ExternalLink className="w-4 h-4 mt-0.5 flex-shrink-0 text-accent" />
              <span>{article.source}</span>
            </div>
          ) : (
            <p className="text-sm text-gray-400 bg-gray-50 rounded-xl p-4">
              Kaynak belirtilmemiş.
            </p>
          )}
        </div>
      </article>
    </div>
  )
}
