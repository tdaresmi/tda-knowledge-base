import { notFound } from 'next/navigation'
import { categories, getArticlesByCategory } from '@/lib/markdown'
import ArticleCard from '@/components/ArticleCard'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export function generateStaticParams() {
  return categories.map((cat) => ({
    slug: cat.slug,
  }))
}

export function generateMetadata({ params }) {
  const category = categories.find(c => c.slug === params.slug)
  return {
    title: category ? `${category.name} - TDA Knowledge Base` : 'Kategori',
  }
}

export default function CategoryPage({ params }) {
  const category = categories.find(c => c.slug === params.slug)

  if (!category) {
    notFound()
  }

  const articles = getArticlesByCategory(params.slug)

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link 
        href="/" 
        className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-accent transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Ana Sayfa
      </Link>

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-primary">{category.name}</h1>
        <p className="text-gray-500 mt-2">{articles.length} makale</p>
      </div>

      {articles.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {articles.map((article) => (
            <ArticleCard key={article.slug} article={article} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-gray-50 rounded-2xl border border-gray-200">
          <p className="text-gray-500">Bu kategoride henüz makale yok.</p>
          <p className="text-sm text-gray-400 mt-2">
            /content/{params.slug}/ klasörüne .md dosyası ekleyin.
          </p>
        </div>
      )}
    </div>
  )
}
