import { categories, getAllArticles } from '@/lib/markdown'
import CategoryCard from '@/components/CategoryCard'
import ArticleCard from '@/components/ArticleCard'
import SearchBar from '@/components/SearchBar'

export default function Home() {
  const articles = getAllArticles()
  const recentArticles = articles.slice(0, 6)

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero */}
      <div className="text-center mb-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-primary mb-4">
          TDA Knowledge Base
        </h1>
        <p className="text-lg text-gray-500 max-w-2xl mx-auto mb-8">
          Açık kaynak bilgi sitesi. Tarihten teknolojiye, bilimden günlük hayata geniş kapsamlı makaleler.
        </p>
        <SearchBar articles={articles.map(a => ({...a, categoryName: categories.find(c => c.slug === a.category)?.name}))} />
      </div>

      {/* Categories */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6">Kategoriler</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map((cat) => (
            <CategoryCard key={cat.slug} category={cat} />
          ))}
        </div>
      </div>

      {/* Recent Articles */}
      {recentArticles.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold text-primary mb-6">Son Makaleler</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentArticles.map((article) => (
              <ArticleCard key={`${article.category}-${article.slug}`} article={article} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
